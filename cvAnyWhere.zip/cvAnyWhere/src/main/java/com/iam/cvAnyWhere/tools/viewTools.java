package com.iam.cvAnyWhere.tools;

import com.iam.cvAnyWhere.cvAnyWhereApp;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;
import java.util.ResourceBundle;

import static com.iam.cvAnyWhere.tools.configs.getConfig;

/**
 * @author Iammm
 * @Time 2024/2/16 13:50
 */
public class viewTools {
    private static final Logger log = LoggerFactory.getLogger(viewTools.class);


    private static Locale locale;
    private static ResourceBundle bundle;

    static {
        log.debug("加载语言包");
        locale = new Locale((String) getConfig("locale"));
        bundle = ResourceBundle.getBundle("com.iam.cvAnyWhere.language", locale);
        log.debug("语言包加载完成,当前语言: {}",locale.getLanguage());
    }

    /**
     * 更改语言
     *
     * @param locale 语言_地区
     * @return boolean 是否成功
     */
    public static boolean changeLanguage(String locale) {
        boolean isSuccess = false;
        if (locale != null && !locale.isEmpty()) {
            var a = (String[]) configs.getConfig("locales");
            isSuccess = Arrays.asList(a).contains(locale);
            if (isSuccess) {
                viewTools.locale = new Locale(locale);
                viewTools.bundle = ResourceBundle.getBundle("com.iam.cvAnyWhere.language", viewTools.locale);
            } else {
                log.debug("语言设置失败，语言包不存在");
            }
        }

        return isSuccess;
    }


    /**
     * 获取视图
     *
     * @param applicationClass 应用程序类
     * @param stage            舞台对象
     * @param fxmlPathname     fxml 路径名
     * @param title            标题
     */
    public static void getView(Class applicationClass, Stage stage, String fxmlPathname, String title) {
        log.debug("加载视图:{}",fxmlPathname);
        FXMLLoader loader = new FXMLLoader(applicationClass.getResource(fxmlPathname),bundle);

        log.debug(String.valueOf(bundle.getLocale()));
        try {
            Parent root = loader.load();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        log.debug("加载视图成功:{}",fxmlPathname);
    }

    /**
     * 获取语言环境
     *
     * @return {@link Locale}
     */
    public Locale getLocale() {
        return locale;
    }
}
