package com.iam.cvAnyWhere;

import javafx.application.Application;
import javafx.stage.Stage;
import com.iam.cvAnyWhere.tools.*;

public class cvAnyWhereApp extends Application {


    public static void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
      viewTools.getView(this.getClass(),primaryStage,"main.fxml","AnyWhere");
    }
}
