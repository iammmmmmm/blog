package com.iam.cvAnyWhere;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Iammm
 * @Time 2024/2/16 13:43
 */
public class run {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(run.class);
    public static void main(String[] args) {
        System.out.println("Hello Pal!");
        log.info("开始运行");
        cvAnyWhereApp.main(args);
    }
}
