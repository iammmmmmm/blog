package com.iam.cvAnyWhere.controller;

import io.javalin.Javalin;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Iammm
 * @Time 2024/2/17 16:37
 */
public class MainController {
    private static final Logger log = LoggerFactory.getLogger(MainController.class);

    public Button test;

    public void testOnActon(ActionEvent event) throws Exception {
        log.debug("testOnActon");
        var app = Javalin.create()
                .get("/", ctx -> ctx.result("Hello Pal"))
                .start(7070);

    }
}
