package com.iam.cvAnyWhere.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;

/**
 * 配置
 *
 * @author Iammm
 * @Time 2024/2/16 13:57
 * @date 2024/02/16
 */
public class configs {
  private static final Logger log = LoggerFactory.getLogger(configs.class);


    private static final HashMap<String,Object> configs = new HashMap<>();
    //def default configs
    static {
        //default locale is zh_CN
        configs.put("locale","zh_CN");
        configs.put("locales",new String[]{"zh_CN","en_US"});
        //default app info
        configs.put("appName","cvAnyWhere");
        configs.put("appVersion","1.0.0");
        configs.put("appAuthor","Iammm");


        configs.forEach((k,v)->log.debug("init config:[key:{},value:{}]",k,v));
    }
    public static void addConfig(String key,Object value){
        configs.put(key,value);
        log.debug("add config:[key:{},value:{}]",key,value);
    }
    public static Object getConfig(String key){
        log.debug("get config:[key:{},value:{}]",key,configs.get(key));
        return configs.get(key);
    }
}
